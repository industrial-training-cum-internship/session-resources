package com.codingstudio.shamirsecretsharing.model

data class AdminInfo(
    val admin : Int,
    val no_of_user: Int,
    val percentage: Int,
)
