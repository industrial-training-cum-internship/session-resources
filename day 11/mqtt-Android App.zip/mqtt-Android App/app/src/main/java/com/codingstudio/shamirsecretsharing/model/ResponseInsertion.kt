package com.codingstudio.shamirsecretsharing.model

data class ResponseInsertion(
    val status: Int,
    val message: String
)