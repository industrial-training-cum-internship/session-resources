package com.codingstudio.shamirsecretsharing.ui.activity

import android.app.Application

class AppApplication : Application() {
}